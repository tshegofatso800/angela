/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Assignment_1;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class LoginTest {

    public LoginTest() {
    }

    // The method under test
    public boolean checkUserName(String username) {
        if (username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            return false;
        }
    }

    @Test
    public void testCheckUserName() {
        // Test case 1: Valid username with an underscore and length <= 5
        assertTrue(checkUserName("abc_1"));
        
        // Test case 2: Invalid username without an underscore
        assertFalse(checkUserName("abcdef"));
        
        // Test case 3: Invalid username with an underscore but length > 5
        assertFalse(checkUserName("abc_def"));
        
        // Test case 4: Valid username with an underscore and length <= 5
        assertTrue(checkUserName("a_b3"));
    }

    @Test
    public void testCheckPasswordComplexity() {
        // Add logic for password complexity test (e.g., minimum length, contains numbers/special characters)
    }

    @Test
    public void testChecksCellPhoneNumber() {
        // Add logic to test phone number format, length, etc.
    }

    @Test
    public void testRegisterUser() {
        // Add logic for user registration test
    }

    @Test
    public void testLoginUsername() {
        // Add logic for testing login with a username
    }

    @Test
    public void testReturnLoginStatus() {
        // Add logic to check if login status returns correctly (e.g., true/false or success/error)
    }
}


